Array.prototype.slice;function e(e){return typeof e==`object`&&`length`in e?e:Array.from(e)}export{e as t};
//# sourceMappingURL=array-BifhSqXX.js.map