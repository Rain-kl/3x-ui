import{at as e,it as t}from"./chunk-DU6HZSFF-CL218LwV.js";var n=(n,r)=>e.lang.round(t.parse(n)[r]);export{n as t};
//# sourceMappingURL=channel-BmQ8dU4S.js.map