import{at as e,it as t}from"./chunk-DU6HZSFF-un5QTOHu.js";var n=(n,r)=>e.lang.round(t.parse(n)[r]);export{n as t};
//# sourceMappingURL=channel-C05r2wk4.js.map